{
  Welcome to SunFTP Server Project, Build: 9(1)

  by Rasmus J.P. Allenheim, Jan Tomasek and others

  Code are compatible with Borland Delphi 3 Std, Pro and C/S
  To compile this project you need the following components:

  RX Libraries from MasterBanks (rx.demo.ru)
  ICS (July 25th 1999) by Franocis Piette (www.rtfm.be/fpiette)
  TSockets from Gary T. Desrosiers (included)
  TDirTree from Markus Stephany (included)
  TAutoRunner from Aleksey Kuznetsov (included)

  This code currently only compiles under Delphi 3

  All code is released under the "lesser" GPL (see license.txt for more info.)
  Code are now Y2K secured, due to a new DateTime function implemented.
  From Build: 9 the file "restricted.lst" have the new name "restricted.ips"

  If you make modifications to the code or use parts of it for
  personal use, please send the modified source to: rasmus@xs4all.dk
  but do not attach the compiled .exe module.

  You can always find the latest build at: http://xs4all.dk/sunftp

  If you have any questions or comments regarding this project, please
  send them to: sunftp@xs4all.dk and mark the mail "q/c".

  //Rasmus, 1999.08.25

  PS! Sorry for the lack of comments in the core source
  DS!
}
